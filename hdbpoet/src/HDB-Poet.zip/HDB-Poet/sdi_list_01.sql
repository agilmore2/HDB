CLEAR COMPUTES
CLEAR BREAKS
SET FEEDBACK OFF
SET PAGESIZE 60
SET LINE 76
SET HEADING ON

column hm_site_code	format a10	heading 'Hydromet|Site Name'
column hm_pcode		format a10	heading 'Hydromet|Parameter'
column site_datatype_id	format 99999999 jus c	heading 'HDB|SiteDataType ID'
column site_id		format 99999999	jus c   heading 'HDB|Site ID'
column datatype_id      format 99999999 jus c   heading 'HDB|Datatype ID'
break on row skip 0;
break on hm_site_code skip 2 page;

spool sdi_list_out.txt
select pcode.hm_site_code,
   pcode.hm_pcode,
   pcode.site_datatype_id,
   datatype.site_id,
   datatype.datatype_id 
from ref_hm_site_pcode pcode,
     hdb_site_datatype datatype
where      
     pcode.site_datatype_id = datatype.site_datatype_id
order by   pcode.hm_site_code, pcode.hm_pcode;
spool off;
     
     
