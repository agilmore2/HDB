Connect ktarbet/newktarbet@uchdb2

set linesize 255;
set pagesize 9999;

set timing on;
select 
joins.checkday date_day,
a.value LSSC, b.value SLSC, c.value LILC, d.value YPSC, e.value ELCC, f.value ELMC,
g.value YBCC, h.value MBLC, i.value YLSC, j.value YPDC, k.value FLGU, l.value JESU,
m.value FCRC, n.value EMGC, o.value EHHC
from 
r_day a, r_day b, r_day c, r_day d,
r_day e, r_day f, r_day g, r_day h,
r_day i, r_day j, r_day k, r_day l,
r_day m, r_day n, r_day o,
/* this COOL subquery just returns date_times 00:00 through num_days*24
   there may be a better way to do this. */
(
select 
to_date('1994-04-01 00:00','YYYY-MM-DD HH24:MI') + (rownum-1) checkday 
from r_day
where rownum <= 122
) joins
where
/* notice the outer joins. These allow any time to not have a value, and
   a null will show up in the right places */
a.site_datatype_id(+) = 2737 and
b.site_datatype_id(+) = 2733 and
c.site_datatype_id(+) = 1337 and
d.site_datatype_id(+) = 1496 and
e.site_datatype_id(+) = 2746 and
f.site_datatype_id(+) = 2231 and
g.site_datatype_id(+) = 2232 and
h.site_datatype_id(+) = 1336 and
i.site_datatype_id(+) = 2739 and
j.site_datatype_id(+) = 1376 and
k.site_datatype_id(+) = 1335 and
l.site_datatype_id(+) = 1361 and
m.site_datatype_id(+) = 3428 and
n.site_datatype_id(+) = 3432 and
o.site_datatype_id(+) = 3430 and
/*finally, get the days in order*/
a.start_date_time(+) = joins.checkday and
b.start_date_time(+) = joins.checkday and
c.start_date_time(+) = joins.checkday AND
d.start_date_time(+) = joins.checkday AND
e.start_date_time(+) = joins.checkday AND
f.start_date_time(+) = joins.checkday AND
g.start_date_time(+) = joins.checkday AND
h.start_date_time(+) = joins.checkday AND
i.start_date_time(+) = joins.checkday AND
j.start_date_time(+) = joins.checkday AND
k.start_date_time(+) = joins.checkday AND
l.start_date_time(+) = joins.checkday AND
m.start_date_time(+) = joins.checkday AND
n.start_date_time(+) = joins.checkday AND
o.start_date_time(+) = joins.checkday 
;


select /*+ use_nl(a) use_nl(b) use_nl(c) use_nl(d) use_nl(e) use_nl(f) use_nl(g) 
use_nl(h) use_nl(i) use_nl(j) use_nl(k) use_nl(l) use_nl(m) use_nl(n) use_nl(o)*/
joins.checkhour start_date_time,
a.value LSSC, b.value SLSC, c.value LILC, d.value YPSC, e.value ELCC, f.value ELMC,
g.value YBCC, h.value MBLC, i.value YLSC, j.value YPDC, k.value FLGU, l.value JESU,
m.value FCRC, n.value EMGC, o.value EHHC
from 
r_hour a, r_hour b, r_hour c, r_hour d,
r_hour e, r_hour f, r_hour g, r_hour h,
r_hour i, r_hour j, r_hour k, r_hour l,
r_hour m, r_hour n, r_hour o,
/* this COOL subquery just returns date_times 00:00 through num_days*24
   there may be a better way to do this. */
(
select /*+ full(r_hour)*/
to_date('1994-04-01 00:00','YYYY-MM-DD HH24:MI') + (rownum-1)/24 checkhour 
from r_hour
where rownum <= 122*24
) joins
where
/* notice the outer joins. These allow any time to not have a value, and
   a null will show up in the right places */
a.site_datatype_id(+) = 2737 and
b.site_datatype_id(+) = 2733 and
c.site_datatype_id(+) = 1337 and
d.site_datatype_id(+) = 1496 and
e.site_datatype_id(+) = 2746 and
f.site_datatype_id(+) = 2231 and
g.site_datatype_id(+) = 2232 and
h.site_datatype_id(+) = 1336 and
i.site_datatype_id(+) = 2739 and
j.site_datatype_id(+) = 1376 and
k.site_datatype_id(+) = 1335 and
l.site_datatype_id(+) = 1361 and
m.site_datatype_id(+) = 3428 and
n.site_datatype_id(+) = 3432 and
o.site_datatype_id(+) = 3430 and
/*finally, get the days in order*/
a.start_date_time(+) = joins.checkhour and
b.start_date_time(+) = joins.checkhour and
c.start_date_time(+) = joins.checkhour AND
d.start_date_time(+) = joins.checkhour AND
e.start_date_time(+) = joins.checkhour AND
f.start_date_time(+) = joins.checkhour AND
g.start_date_time(+) = joins.checkhour AND
h.start_date_time(+) = joins.checkhour AND
i.start_date_time(+) = joins.checkhour AND
j.start_date_time(+) = joins.checkhour AND
k.start_date_time(+) = joins.checkhour AND
l.start_date_time(+) = joins.checkhour AND
m.start_date_time(+) = joins.checkhour AND
n.start_date_time(+) = joins.checkhour AND
o.start_date_time(+) = joins.checkhour
;
