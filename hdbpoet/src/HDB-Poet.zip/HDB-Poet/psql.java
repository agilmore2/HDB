import java.net.*;
import java.io.*;
import java.sql.*;
import java.math.*;
public class psql 
{
   public static void main(String[] args) 
   {     Connection con=null;
     Statement stmt=null;

     try
     {

         DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

         con = DriverManager.getConnection("jdbc:oracle:thin:@sun1.yak.pn.usbr.gov:1521:yakhdb","yakhdb","duncan08");

         stmt = con.createStatement();
  //insert a value    
        String insert = "insert into r_instant values (20359,sysdate,1.2,14,'Z',sysdate)";
        System.out.println(insert);
        stmt.executeUpdate(insert);
//now check it
         String query = "select * from r_instant where source_id=14";
         System.out.println(query);
         ResultSet rs = stmt.executeQuery(query);
        
         rs.next(); 
         int s1 = rs.getInt("site_datatype_id");
         int s2 = rs.getInt("source_id");
         System.out.println(s1+" "+s2);

         stmt.close();
      }
      catch(SQLException ex)
      {
         System.err.println("CONNection Problem:"+ex.getMessage());
      }

//      catch(java.lang.ClassNotFoundException e)
  //    {
    //     System.err.println("DRIVER Problem:"+e.getMessage());
      //}
     
   }
}