using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Diagnostics;
using System.Windows.Forms;
using System.IO;
using Karl.Tools;
using Karl.Tools.TimeSeries;

namespace HDBBrowser
{
	/// <summary>
	/// Summary description for 
	/// </summary>
	public class HDBBrowser : System.Windows.Forms.UserControl
	{
	
		Oracle oracle = null;
		TimeSeriesDataSet graphDef;
		bool SetActiveCellNeeded = false;
		DataGridCell ActiveCell;
		GraphProperties graphProperties;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.ToolTip toolTip1;
		private System.Windows.Forms.Panel panelGraphTable;
		private System.Windows.Forms.StatusBarPanel statusBarPanel1;
		private System.Windows.Forms.StatusBarPanel statusBarPanel2;
		private System.Windows.Forms.Splitter splitter1;
		private System.Windows.Forms.Panel PanelChart;
		private System.Windows.Forms.Panel panel1;
		private Steema.TeeChart.TChart chart;
		private Steema.TeeChart.Tools.DragPoint dragPoint1;
		private System.Windows.Forms.ContextMenu contextMenuChart;
		private System.Windows.Forms.MenuItem menuItemChartProperties;
		private System.Windows.Forms.MenuItem menuItemUndoZoom;
		private System.Windows.Forms.MenuItem menuItemDates;
		private System.Windows.Forms.MenuItem menuItemRefresh;
		private System.Windows.Forms.MenuItem menuItemEditSeries;
		private Karl.Tools.TimeSeries.TimeSeriesSpreadsheet timeSeriesSpreadsheet1;
		private System.ComponentModel.IContainer components;

		public HDBBrowser()
		{
			InitializeComponent();
			UserPreference up = new UserPreference();
			oracle = HDB.Oracle;
			if( oracle==null)
			{
				throw new Exception("error:  oracle not connected");
			}
			graphDef = new TimeSeriesDataSet();
			string sw = up.Lookup("ChartWidth");
			if(sw!= null && sw.Length>0)
			{
				int w = Convert.ToInt32(sw);
				this.PanelChart.Width=w;
			}
		}

		public void Print()
		{
		  chart.Printer.Preview();
		}
		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusBarPanel1 = new System.Windows.Forms.StatusBarPanel();
			this.statusBarPanel2 = new System.Windows.Forms.StatusBarPanel();
			this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
			this.panelGraphTable = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.timeSeriesSpreadsheet1 = new Karl.Tools.TimeSeries.TimeSeriesSpreadsheet();
			this.splitter1 = new System.Windows.Forms.Splitter();
			this.PanelChart = new System.Windows.Forms.Panel();
			this.chart = new Steema.TeeChart.TChart();
			this.contextMenuChart = new System.Windows.Forms.ContextMenu();
			this.menuItemRefresh = new System.Windows.Forms.MenuItem();
			this.menuItemDates = new System.Windows.Forms.MenuItem();
			this.menuItemUndoZoom = new System.Windows.Forms.MenuItem();
			this.menuItemChartProperties = new System.Windows.Forms.MenuItem();
			this.menuItemEditSeries = new System.Windows.Forms.MenuItem();
			this.dragPoint1 = new Steema.TeeChart.Tools.DragPoint();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).BeginInit();
			this.panelGraphTable.SuspendLayout();
			this.panel1.SuspendLayout();
			this.PanelChart.SuspendLayout();
			this.SuspendLayout();
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 457);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusBarPanel1,
																						  this.statusBarPanel2});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(832, 24);
			this.statusBar1.TabIndex = 26;
			this.statusBar1.DoubleClick += new System.EventHandler(this.statusBar1_DoubleClick);
			// 
			// statusBarPanel1
			// 
			this.statusBarPanel1.Width = 200;
			// 
			// statusBarPanel2
			// 
			this.statusBarPanel2.Width = 500;
			// 
			// panelGraphTable
			// 
			this.panelGraphTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.panelGraphTable.Controls.Add(this.panel1);
			this.panelGraphTable.Controls.Add(this.splitter1);
			this.panelGraphTable.Controls.Add(this.PanelChart);
			this.panelGraphTable.Location = new System.Drawing.Point(0, 0);
			this.panelGraphTable.Name = "panelGraphTable";
			this.panelGraphTable.Size = new System.Drawing.Size(832, 464);
			this.panelGraphTable.TabIndex = 27;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.timeSeriesSpreadsheet1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(659, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(173, 464);
			this.panel1.TabIndex = 2;
			// 
			// timeSeriesSpreadsheet1
			// 
			this.timeSeriesSpreadsheet1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.timeSeriesSpreadsheet1.Location = new System.Drawing.Point(0, 0);
			this.timeSeriesSpreadsheet1.Name = "timeSeriesSpreadsheet1";
			this.timeSeriesSpreadsheet1.Size = new System.Drawing.Size(173, 464);
			this.timeSeriesSpreadsheet1.TabIndex = 0;
			this.timeSeriesSpreadsheet1.SaveChanges += new System.EventHandler(this.timeSeriesSpreadsheet1_SaveChanges);
			this.timeSeriesSpreadsheet1.SpreadsheetEditOccured += new System.EventHandler(this.timeSeriesSpreadsheet1_SpreadsheetEditOccured);
			this.timeSeriesSpreadsheet1.SpreadsheetIndexChanged += new System.EventHandler(this.timeSeriesSpreadsheet1_SpreadsheetIndexChanged);
			// 
			// splitter1
			// 
			this.splitter1.Location = new System.Drawing.Point(656, 0);
			this.splitter1.Name = "splitter1";
			this.splitter1.Size = new System.Drawing.Size(3, 464);
			this.splitter1.TabIndex = 1;
			this.splitter1.TabStop = false;
			// 
			// PanelChart
			// 
			this.PanelChart.Controls.Add(this.chart);
			this.PanelChart.Dock = System.Windows.Forms.DockStyle.Left;
			this.PanelChart.Location = new System.Drawing.Point(0, 0);
			this.PanelChart.Name = "PanelChart";
			this.PanelChart.Size = new System.Drawing.Size(656, 464);
			this.PanelChart.TabIndex = 0;
			this.PanelChart.Resize += new System.EventHandler(this.PanelChart_Resize);
			// 
			// chart
			// 
			this.chart.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			// 
			// chart.Aspect
			// 
			this.chart.Aspect.View3D = false;
			this.chart.ContextMenu = this.contextMenuChart;
			// 
			// chart.Header
			// 
			// 
			// chart.Header.Font
			// 
			// 
			// chart.Header.Font.Brush
			// 
			this.chart.Header.Font.Brush.Color = System.Drawing.Color.Black;
			this.chart.Header.Font.Size = 14;
			this.chart.Header.Lines = new string[0];
			this.chart.Location = new System.Drawing.Point(0, 0);
			this.chart.Name = "chart";
			this.chart.Size = new System.Drawing.Size(656, 464);
			this.chart.TabIndex = 0;
			this.chart.Tools.Add(this.dragPoint1);
			this.chart.MouseUp += new System.Windows.Forms.MouseEventHandler(this.chart_MouseUp);
			// 
			// contextMenuChart
			// 
			this.contextMenuChart.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							 this.menuItemRefresh,
																							 this.menuItemDates,
																							 this.menuItemUndoZoom,
																							 this.menuItemChartProperties,
																							 this.menuItemEditSeries});

			// 
			// menuItemRefresh
			// 
			this.menuItemRefresh.Index = 0;
			this.menuItemRefresh.Text = "&Refresh";
			this.menuItemRefresh.Click += new System.EventHandler(this.menuItemRefresh_Click);
			// 
			// menuItemDates
			// 
			this.menuItemDates.Index = 1;
			this.menuItemDates.Text = "&Dates";
			this.menuItemDates.Click += new System.EventHandler(this.menuItemDates_Click);
			// 
			// menuItemUndoZoom
			// 
			this.menuItemUndoZoom.Index = 2;
			this.menuItemUndoZoom.Text = "&Undo Zoom";
			this.menuItemUndoZoom.Click += new System.EventHandler(this.menuItemUndoZoom_Click);
			// 
			// menuItemChartProperties
			// 
			this.menuItemChartProperties.Index = 3;
			this.menuItemChartProperties.Text = "&Properties";
			this.menuItemChartProperties.Click += new System.EventHandler(this.menuItemChartProperties_Click);
			// 
			// menuItemEditSeries
			// 
			this.menuItemEditSeries.Index = 4;
			this.menuItemEditSeries.Text = "&Edit Series";
			this.menuItemEditSeries.Click += new System.EventHandler(this.menuItemEditSeries_Click);
			// 
			// dragPoint1
			// 
			this.dragPoint1.Active = false;
			this.dragPoint1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.dragPoint1.Style = Steema.TeeChart.Tools.DragPointStyles.Y;
			this.dragPoint1.Drag += new Steema.TeeChart.Tools.DragPointEventHandler(this.dragPoint1_Drag);
			// 
			// HDBBrowser
			// 
			this.AllowDrop = true;
			this.Controls.Add(this.panelGraphTable);
			this.Controls.Add(this.statusBar1);
			this.Name = "HDBBrowser";
			this.Size = new System.Drawing.Size(832, 481);
			this.DragEnter += new System.Windows.Forms.DragEventHandler(this.HDBBrowser_DragEnter);
			this.DragDrop += new System.Windows.Forms.DragEventHandler(this.HDBBrowser_DragDrop);
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusBarPanel2)).EndInit();
			this.panelGraphTable.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.PanelChart.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

    public void OpenFile(string filename)
    {
    try
    {
      if( this.oracle == null)
        return;
      //this.timeSeriesSpreadsheet1.DataSource=null;
      Cursor = Cursors.WaitCursor;
      graphDef = new TimeSeriesDataSet();
      graphDef.Clear();
      graphDef.ReadXml(filename);
      Graph(true);
      }
      finally
      {
      Cursor = Cursors.Default;
      }
		if( FilenameChanged!=null)
		{
			HDBPoetEventArgs ea  =new HDBPoetEventArgs(filename,this.graphDef);
			FilenameChanged(null,ea);
		}
    }
	
	public delegate void OnFileChanged(object sender, HDBPoetEventArgs fe);
	public event OnFileChanged FilenameChanged;

		public class HDBPoetEventArgs: EventArgs 
		{
			public string filename;
			public TimeSeriesDataSet graphDef;

			public HDBPoetEventArgs(string filename, TimeSeriesDataSet graphDef) 
			{
				this.filename = filename;
				this.graphDef = graphDef;
			}

		}   


	
  
    
    /// <summary>
    /// Redraw graph with in-memory data
    /// </summary>
    void Graph()
    {
      Graph(false);
    }
    /// <summary>
    /// Redraw graph. 
    /// </summary>
    /// <param name="reloadFromOracle">set to true to get fresh data from database</param>
    void Graph(bool reloadFromOracle)
    {
      if( graphDef == null || graphDef.Series.Rows.Count==0)
        return;
        if( reloadFromOracle) // reload will lose any edits
         {
        HDB.Fill(graphDef);
        dragPoint1.Active = false;
          this.timeSeriesSpreadsheet1.DataSource = graphDef;
        }
     
      Karl.Tools.TimeSeries.Graphs.StandardTChart(graphDef,chart);
      this.menuItemUndoZoom_Click(null,null);
      
    }

    public void SaveFullGraph(string filename)
    {
      this.graphDef.WriteXml(filename,XmlWriteMode.WriteSchema);
    }
    
		private void statusBar1_DoubleClick(object sender, System.EventArgs e)
		{
			SqlView sqlView = new SqlView(this.oracle);	
			sqlView.ShowDialog();
		}

    /// <summary>
    /// Creates a new graph.
    /// </summary>
    /// <returns>returns true if a new graph was created</returns>
		public bool NewGraph()
		{
			if( oracle == null)
			{
				return false;
			}
			TimeSeriesDataSet newDataSet = new TimeSeriesDataSet();

			if(graphProperties == null)
			{
				graphProperties = new GraphProperties(newDataSet);
			}
			else
			{
				graphProperties.DataSet= newDataSet;
			}
			if( graphProperties.ShowDialog() == DialogResult.OK)
			{
				this.graphDef= newDataSet;
				HDB.Fill(graphDef);
				this.timeSeriesSpreadsheet1.DataSource=graphDef;
				Graph();
				return true;
			}
			return false;
		}

		public void SaveGraph(string filename)
		{
			if( graphDef == null)
				return;
			TimeSeriesTools.Save(filename,graphDef,false);
		}

    /// <summary>
    /// When user clicks graph-->Properties menu
    /// </summary>
    public void EditProperties()
    {
      GraphProperties g = new GraphProperties(graphDef);
       if( g.ShowDialog() == DialogResult.OK)
         {
         HDB.Fill(graphDef);
         Graph();
         }
    }
    
    
		

		

    private void dragPoint1_Drag(Steema.TeeChart.Tools.DragPoint sender, int Index)
    {
      int seriesIndex = timeSeriesSpreadsheet1.TableIndex;
      if( seriesIndex >=0)
      {
        double val = chart[seriesIndex].YValues[Index];
        val = Math.Round(val,2);
        chart[seriesIndex].YValues[Index] = val;

        this.timeSeriesSpreadsheet1.DataTable.Rows[Index][1] = val;
        SetActiveCellNeeded = true;
        ActiveCell = new DataGridCell(Index,seriesIndex);
        
      }
		
    }
    private void chart_MouseUp(object sender, MouseEventArgs e)
    {
      if( SetActiveCellNeeded)
      {
        timeSeriesSpreadsheet1.CurrentCell = ActiveCell;
        SetActiveCellNeeded = false;
      }
    }

    
    /// <summary>
    /// finds a new unique filename
    /// </summary>
    /// <returns></returns>
    private string NewFilename()
    {
      string fn = "";
      for(int i=1; i<9999; i++)
        {
        fn = "Graph"+i.ToString()+".hdb";
        if( !File.Exists(fn+".hdb"))
          {
          return fn;
          }
        }
       return "untitled";
    }


    private void menuItemChartProperties_Click(object sender, System.EventArgs e)
    {
      chart.ShowEditor();
    }

    private void menuItemUndoZoom_Click(object sender, System.EventArgs e)
    {
    chart.Zoom.Undo();
    chart.Zoom.ZoomPercent(97);
    }


    private void menuItemDates_Click(object sender, System.EventArgs e)
    {
      Karl.Tools.TimeSeries.TimeSelectorForm f = new TimeSelectorForm();
      
      TimeSeriesTools.SetDefaults(graphDef);
      TimeSeriesDataSet.GraphRow r;
       r =  this.graphDef.Graph[0];

       f.BeginningTime = TimeSeriesTools.BeginingTime(graphDef);
       f.EndingTime = TimeSeriesTools.EndingTime(graphDef);
           
      if( f.ShowDialog() == DialogResult.OK )
        {           
        r.TimeWindowType = "FromXToY";        
        r.BeginningDate  = f.BeginningTime;
        r.EndingDate     = f.EndingTime;
        this.Graph(true);
        }
    }

    private void timeSeriesSpreadsheet1_SpreadsheetIndexChanged(object sender, System.EventArgs e)
    {
      int seriesIndex = timeSeriesSpreadsheet1.TableIndex;
      if ( seriesIndex >=0)
      {
        Debug.Assert( seriesIndex < chart.Series.Count);
        dragPoint1.Series = chart[seriesIndex];
        dragPoint1.Active = true;
      }
      else
        {
        dragPoint1.Active = false;
        }
    }

    private void timeSeriesSpreadsheet1_SpreadsheetEditOccured(object sender, System.EventArgs e)
    {
     Graph(false);
     int seriesIndex = timeSeriesSpreadsheet1.TableIndex;
      if( seriesIndex <0)
        return;
     dragPoint1.Series = chart[seriesIndex];
    }

    private void menuItemRefresh_Click(object sender, System.EventArgs e)
    {
      Graph(true);
    }

    private void menuItemEditSeries_Click(object sender, System.EventArgs e)
    {
        if( oracle == null|| graphDef ==null )
        {
          return;
        }
        //GraphProperties g;
        Cursor = Cursors.WaitCursor;
        try
        {
			if( graphProperties == null)
			{
				graphProperties = new GraphProperties(this.graphDef);
			}
        }
        finally
        {
          Cursor = Cursors.Default;
        }
	  graphProperties.DataSet=this.graphDef;
      if( graphProperties.ShowDialog() == DialogResult.OK)
      {
      Graph(true);
      }

    }

    private void HDBBrowser_DragEnter(object sender, System.Windows.Forms.DragEventArgs e)
    {
      if( e.Data.GetDataPresent(DataFormats.FileDrop) )
        e.Effect = DragDropEffects.All;
    }

    private void HDBBrowser_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
    {
      try
      {
        if( e.Data.GetDataPresent(DataFormats.FileDrop) )
        {
          String[] MyFiles;
          MyFiles = (string[])e.Data.GetData(DataFormats.FileDrop);

          if (MyFiles != null && MyFiles.Length>0)
          { // take first hdb file dropped in case of multiple
            this.OpenFile(MyFiles[0].ToString());          
			  
          }
        }
      }
      catch(Exception exc)
      {
      MessageBox.Show("Error dragging file",exc.ToString());
      }
    }

    private void timeSeriesSpreadsheet1_SaveChanges(object sender, System.EventArgs e)
    {
      int numSeries = this.graphDef.Series.Count;
      for(int i=0; i<numSeries; i++)
      {
      // any changes for this series?
           string tblName = "table"+Convert.ToString(i);
        DataTable tbl = graphDef.Tables[tblName].GetChanges(DataRowState.Modified);

        if( tbl ==null || tbl.Rows.Count==0)
        {
          continue;
        }
      // is this edit possible?
       string flag = HDB.OverwriteInfo(graphDef.Series[i].hdb_site_datatype_id,graphDef.Series[i].TimeStep);

        if( flag.IndexOf("ERROR_") >=0)
        {
          string msg2 = "";
          if( !graphDef.Series[i].IsSiteNameNull())
            msg2+=graphDef.Series[i].SiteName;
          if( !graphDef.Series[i].IsParameterTypeNull())
             msg2 +=" "+graphDef.Series[i].ParameterType;


			// Fatal Errors...
			if(flag.IndexOf("NO_SOURCE_INTERVAL")>=0
				 || flag.IndexOf("UNKNOWN")>=0)
			{
				MessageBox.Show ("Time Series cannot be saved, overwrite status unknown:\n "+msg2
				,flag,  
				MessageBoxButtons.OK, MessageBoxIcon.Error);
				continue;
			}

			//  Likely error, but user may perform "overwrite"

			if (MessageBox.Show ("Time Series cannot be saved, overwrite status unknown:\n "+msg2
				+" Proceed anyway"
				,flag,  
				MessageBoxButtons.YesNo, MessageBoxIcon.Question)
				!= DialogResult.Yes) 
			{
				continue;
			}
		 flag = "O";
        }

      // what is overwrite flag
        if( flag == "NULL" )
        {
        flag = null;
        }
        
      // save changes to HDB
        for(int r=0; r<tbl.Rows.Count; r++)
        {
          HDB.modify_r_base(graphDef.Series[i].hdb_site_datatype_id,
            graphDef.Series[i].TimeStep,
            (DateTime)tbl.Rows[r]["START_DATE_TIME"],
            DateTime.MinValue,
            (double)tbl.Rows[r]["Value"],
            flag,
            "Z",
            "Y");
        }
      }
    }

		private void PanelChart_Resize(object sender, System.EventArgs e)
		{
			UserPreference up =new UserPreference();
			up.Change("ChartWidth",this.PanelChart.Width.ToString());
			up.Save();
		}

		

	
  }
}
