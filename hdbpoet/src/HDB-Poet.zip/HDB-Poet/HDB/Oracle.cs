using System;
using System.Data;
using System.Diagnostics;
using System.Data.OleDb;
using System.Collections;
using System.Windows.Forms;

namespace Karl.Tools
{
	/// <summary>
	/// class Oracle contains methods to access
	/// data from the Yakima HDB database.
	/// </summary>
	public class Oracle
	{
		string strAccessConn = null;
		string lastSqlCommand;
		public ArrayList sqlCommands  = new ArrayList();
		string lastMessage;
        string username,service="";
		bool loginCanceled = false;
		public static string DateFormat = "MM/dd/yyyy";


		/// <summary>
		/// Creates instance of Oracle class and prompts user for
		/// login info.
		/// </summary>
		public Oracle()
		{   
			OracleLogin login = new OracleLogin();
			if( login.ShowDialog() != DialogResult.OK)
			{
				loginCanceled=true;
			}
			username = login.username;
			this.service = login.service;
			MakeConnectionString(login.username,login.password,login.provider,login.service);
			//sqlCommands.Clear();
		}

		public bool LoginCanceled
		{
			get { return loginCanceled;}
		}
		
		public string ServiceName
		{
		  get { return this.service;}
		}
		
		public string ConnectionString
		{
		  get { return this.strAccessConn;}
		}
		/// <summary>
		/// Creates instance of Oracle class with inputs.
		/// </summary>
		public Oracle(string username, string password, string provider, string service)
		{
			sqlCommands.Clear();
			MakeConnectionString(username,password,provider,service);
		}


		/// <summary>
		/// returns true if connection is working.
		/// </summary>
		/// <returns></returns>
		public bool ConnectionWorking()
		{
			string sql = "select count(*) from hdb_site";
			DataTable tbl  = this.Table("test",sql);

			if(tbl.Rows.Count <=0)
				return false;
			else return true;
		}


		void MakeConnectionString(string username, string password, string provider, string service)
		{
			strAccessConn = "Provider="+provider+";User ID="+username+";"
				+"Password="+password+"; Data Source="+service+";";
		}

		/// <summary>
		/// For testing... dumps full database to xml.
		/// </summary>
		/// <param name="XmlFilename"></param>
		public void ExportToXML(string XmlFilename)
		{
			DataSet myDataSet = new DataSet();
			OleDbConnection myAccessConn = new OleDbConnection(strAccessConn);
			OleDbCommand myAccessCommand = new OleDbCommand();
			OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(myAccessCommand);

			DataTable tbls = GetTables();
			try
			{
				myAccessConn.Open();
				Console.WriteLine("Found "+tbls.Rows.Count+" tables");
				for(int i=0; i< tbls.Rows.Count; i++)
				{
					string tableName = (string) tbls.Rows[i]["TABLE_NAME"];
					if( tableName == "Message")
						continue;
					if(tableName.IndexOf("SITE") >=0 )
						continue;

					Console.Write(tableName+ ":");
					myDataSet.Tables.Add(tableName);
					string sql = "Select * FROM "+tableName;
					myDataAdapter.SelectCommand = new OleDbCommand(sql,myAccessConn);
					myDataAdapter.Fill(myDataSet,0,20,tableName); // limit to 20 records per table.

					Console.WriteLine(myDataSet.Tables[tableName].Rows.Count);
					
				}
			}
			finally
			{
				myAccessConn.Close();
			}
			
			myDataSet.WriteXml(XmlFilename,XmlWriteMode.WriteSchema);
		}
		/// <summary>
		///returns a list of tables. 
		/// </summary>
		/// <param name="conn"></param>
		/// <returns></returns>
		public DataTable GetTables()
		{
			DataSet myDataSet = new DataSet();
			OleDbConnection conn = new OleDbConnection(strAccessConn);
			conn.Open();
			DataTable schemaTable = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables,
				new object[] {null, null, null, "TABLE"});
			conn.Close();
			return schemaTable;
		}
	

		/// <summary>
		/// Appends data to database.  
		/// </summary>
		/// <param name="table">Table whose contents will be appended to datbase.</param>
		/// <param name="StopOnError">Set StopOnError to true to stop processing when any error occurrs.  Set to false to continue when errors occur</param>
		public  void InsertTable(DataTable table, bool StopOnError)
		{
			int sz = table.Rows.Count;
			int cols = table.Columns.Count;

			string strAccessConn = this.strAccessConn;
			OleDbConnection myConnection = new OleDbConnection(strAccessConn);
			myConnection.Open();

			OleDbCommand myCommand = new OleDbCommand();
			OleDbTransaction myTrans =null;

			// Start a local transaction
			
		string cmd = "";
			try
			{

				for(int i=0; i<sz; i++)
				{
					try
					{
						myTrans = myConnection.BeginTransaction(IsolationLevel.ReadCommitted);
						// Assign transaction object for a pending local transaction
						myCommand.Connection = myConnection;
						myCommand.Transaction = myTrans;

						 cmd = "insert into "+table.TableName+" Values ( ";
						for(int c = 0; c<cols; c++)
						{
							object o = table.Rows[i][c];
							string type =o.GetType().ToString();

							if( o == System.DBNull.Value)
							{
								//Console.WriteLine("");
								cmd += "NULL";
							}
							else
							if( type == "System.String")
							{// enclose with quotes.
								cmd += "'"+o.ToString()+"'";
							}
							else
								if( type == "System.DateTime")
							{
								
								DateTime time = (DateTime)o;
							
								cmd += "'"+time.ToString("yyyy-MM-dd HH:mm:ss.000")+"'";
							}
							else
							{
								cmd += o.ToString();
							}

							if( c!= cols-1)
								cmd += ",";

						}
						cmd += ")";
						myCommand.CommandText = cmd;
						myCommand.ExecuteNonQuery();
					}
					catch(Exception ex)
					{
					this.lastMessage = ex.ToString();
					myTrans.Rollback();
						if( StopOnError)
						{
							throw ex;
						}
						continue;
					}

				myTrans.Commit();
				}
				
			}
			catch(Exception e)
			{
				this.lastMessage = e.ToString();
				Console.WriteLine(e.ToString());
			}
			finally
			{
				myConnection.Close();
			}

		}
		/// <summary>
		/// retrieves more data into the dataTable specified.
		/// </summary>
		/// <param name="dataTable"></param>
		/// <param name="sql"></param>
		public void AppendToTable(DataTable dataTable,string sql)
		{
			string strAccessSelect = sql;
			OleDbConnection myAccessConn = new OleDbConnection(strAccessConn);
			OleDbCommand myAccessCommand = new OleDbCommand(strAccessSelect,myAccessConn);
			OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(myAccessCommand);
		
			//Console.WriteLine(sql);
			this.lastSqlCommand = sql;
			this.sqlCommands.Add(sql);
			DataSet myDataSet =dataTable.DataSet;
			//myDataSet.Tables.Add(dataTable);
			string tableName = dataTable.TableName;
			try
			{
				myAccessConn.Open();
				
				myDataAdapter.Fill(myDataSet,tableName);
			}
			catch(Exception e)
			{
				string msg = "Error reading from database "+sql +" Exception "+e.ToString();
				Console.WriteLine(msg);
				System.Windows.Forms.MessageBox.Show (msg, "Error", 
					System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
				//throw e; 
			}
			finally
			{
				myAccessConn.Close();
			}
			//DataTable tbl = myDataSet.Tables[tableName];
			//return tbl;
		}

		public DataTable Table(string tableName,string sql)
		{
				string strAccessSelect = sql;
				OleDbConnection myAccessConn = new OleDbConnection(strAccessConn);
				OleDbCommand myAccessCommand = new OleDbCommand(strAccessSelect,myAccessConn);
				OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(myAccessCommand);
		
			//Console.WriteLine(sql);
			this.lastSqlCommand = sql;
			this.sqlCommands.Add(sql);
			DataSet myDataSet = new DataSet();
      try
      {
        myAccessConn.Open();
				
        myDataAdapter.Fill(myDataSet,tableName);
      }
      catch(Exception e)
      {
        string msg = "Error reading from database "+sql +" Exception "+e.ToString();
		  Console.WriteLine(msg);
        System.Windows.Forms.MessageBox.Show (msg, "Error", 
          System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Error);
		//throw e; 
      }
      finally
      {
        myAccessConn.Close();
      }
				DataTable tbl = myDataSet.Tables[tableName];
				return tbl;
	 }

     
		public int RunSqlCommand(string sql)
		{
		return this.RunSqlCommand(sql,this.strAccessConn);
		}
		
		
		public int RunStoredProc(OleDbCommand cmd )
		{
		int rval=0;
      OleDbConnection conn = new OleDbConnection(this.strAccessConn);
      Debug.Assert(cmd.CommandType == CommandType.StoredProcedure);
      
      //OleDbCommand cmd = new OleDbCommand("myCmd", conn);
      cmd.Connection = conn;
      /*
      OleDbCommand cmd = new OleDbCommand("myCmd", conn);
      cmd.CommandType = CommandType.StoredProcedure;
      cmd.Parameters.Add("amount",OleDbType.Integer,16);
      cmd.Parameters["amount"].Value = 200 ;  
      cmd.Parameters["amount"].Direction = ParameterDirection.Input ;
      */
      try{
      conn.Open();
      rval = cmd.ExecuteNonQuery();
      }
      catch(Exception exc)
      {
      Console.WriteLine(exc.ToString());
      rval = -1;
      }
      
      conn.Close();
      this.lastSqlCommand = cmd.CommandText;
      this.sqlCommands.Add(cmd.CommandText);
      return rval;
		}
		/// <summary>
		/// runs sql command.
		/// returns number of rows affected.
		/// </summary>
		/// <returns></returns>
		public int RunSqlCommand(string sql, string strAccessConn)
		{
			int rval =0;
            this.lastMessage = "";
			OleDbConnection myConnection = new OleDbConnection(strAccessConn);
			myConnection.Open();
			OleDbCommand myCommand = new OleDbCommand();
			OleDbTransaction myTrans;

			// Start a local transaction
			myTrans = myConnection.BeginTransaction(IsolationLevel.ReadCommitted);
			// Assign transaction object for a pending local transaction
			myCommand.Connection = myConnection;
			myCommand.Transaction = myTrans;

			try
			{
				myCommand.CommandText = sql;
				rval = myCommand.ExecuteNonQuery();
				myTrans.Commit();
				this.lastSqlCommand = sql;
				this.sqlCommands.Add(sql);
			}
			catch(Exception e)
			{
				myTrans.Rollback();
				Console.WriteLine(e.ToString());
				System.Windows.Forms.MessageBox.Show("Error running command :"+sql+" exception: "+e.ToString());
				Console.WriteLine("Error running "+sql);
                this.lastMessage = e.ToString();
				rval = -1;
				//throw e;
			}
			finally
			{
				myConnection.Close();
			}
		return rval;
		}
		
		public string[] SqlHistory
		{
			get
			{
				string[] rval = new String[sqlCommands.Count];
				this.sqlCommands.CopyTo(rval);
				return rval;
			}
			set
			{
				this.sqlCommands.Clear();
				for(int i=0; i<value.Length; i++)
				{
					this.sqlCommands.Add(value[i]);
				}
			}
		
		}
		public string LastSqlCommand
		{
			get{return this.lastSqlCommand; }
		}


    
				
	}
}
