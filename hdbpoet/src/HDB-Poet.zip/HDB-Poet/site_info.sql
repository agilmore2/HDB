Connect ktarbet/newktarbet@uchdb2;
set pagesize 9999;
set linesize 132;

  select 'daily' interval,d.datatype_id, d.datatype_common_name,
   count(a.value),'r_day' "rtable", max(a.site_datatype_id) "site_datatype_id" ,
   max(b.site_id) "site_id", min(start_date_time), max(start_date_time)  
   from  r_day a, hdb_site_datatype b, hdb_datatype d 
   where  a.site_datatype_id = b.site_datatype_id and  b.datatype_id = d.datatype_id 
   and  b.site_id = 736 group by d.datatype_id, d.datatype_common_name  
;