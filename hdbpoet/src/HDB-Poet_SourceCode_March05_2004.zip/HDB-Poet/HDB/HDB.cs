using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;
using Karl.Tools;
using Karl.Tools.TimeSeries;
namespace HDBBrowser
{
	/// <summary>
	/// Summary description for HDB.
	/// </summary>
	public class HDB
	{
		static Oracle oracle;
		//static DataTable prev_siteList;
		//static DataTable _hydrometSiteTable;
		static DataTable _categories;
		static DataTable _object_types;

    static int HDB_INVALID_ID =-1;
    static decimal  static_AGEN_ID=HDB_INVALID_ID;
    static decimal  static_COLLECTION_SYSTEM_ID=HDB_INVALID_ID;
    static decimal  static_LOADING_APPLICATION_ID = HDB_INVALID_ID;
    static decimal  static_METHOD_ID=HDB_INVALID_ID;
    static decimal  static_COMPUTATION_ID=HDB_INVALID_ID;
		
		static string[] r_tables     ={"r_instant",    "r_hour",   "r_day",   "r_month",   "r_year",   "r_wy"};
		//public static string[] r_names      ={"instantaneous","hourly",   "daily",   "monthly",   "yearly",   "water year"};
    public static string[] r_names      ={"instant","hour",   "day",   "month",   "year",   "wy"};
		static string[] date_columns ={"start_date_time",    "start_date_time","start_date_time","start_date_time","start_date_time","start_date_time"};

		public static Oracle Oracle
		{
			get { return oracle;}
			set { oracle = value;}
		}
    static string OracleDate(DateTime date)
    {
      string rval = " TO_Date('"+date.ToString(Oracle.DateFormat)+"', '"+ Oracle.DateFormat +"') ";
      return rval;
    }
    
    /// <summary>
    /// OverwriteInfo is called by the interface 
    /// to inform the user about editing that is not allowed.
    /// possible return values.
    /// ------------------
    /// 'O'  - this is overwrite use 'O' for Overwrite_flag
    /// 'NULL'   - this is not overwrite, use null for overwrite_flag, is source interval
    /// 'ERROR'  - no derivations are defined for this sdi, inform user and do not insert.
    /// //	'NO_DERIV'	     - no derivation specification for this sdi exists, data will not move out of r_base unless 'O' is used
    /// Other flags may be defined as procedure evolves.
    ///  
    /// </summary>
  public static string OverwriteInfo(decimal site_datatype_id, string interval)
  {
    string result="ERROR";
    try
    {
    OleDbCommand cmd = new OleDbCommand("IS_OVERWRITE");
    cmd.CommandType = CommandType.StoredProcedure;

    cmd.Parameters.Add("SITE_DATATYPE_ID_IN",OleDbType.Numeric );
    cmd.Parameters["SITE_DATATYPE_ID_IN"].Value =site_datatype_id;
    cmd.Parameters["SITE_DATATYPE_ID_IN"].Direction = ParameterDirection.Input ;

    cmd.Parameters.Add("INTERVAL_IN",OleDbType.VarChar);
    cmd.Parameters["INTERVAL_IN"].Value =interval;
    cmd.Parameters["INTERVAL_IN"].Direction = ParameterDirection.Input ;

    cmd.Parameters.Add("OVERWRITE_INFO",OleDbType.VarChar);
    cmd.Parameters["OVERWRITE_INFO"].Direction = ParameterDirection.Output ;
    cmd.Parameters["OVERWRITE_INFO"].Size=10;
    oracle.RunStoredProc(cmd);
    result = cmd.Parameters["OVERWRITE_INFO"].Value.ToString();
  }
    catch(Exception e)
  {
    MessageBox.Show("Oracle Error: "+e.Message);
  }
      
    return result;
  }

    /// <summary>
    /// LookupApplication calls a stored procedure to 
    /// determine what id the hdb-poet application is using for the 
    /// specific HDB you are logged into.
    /// 
    /// Some other id's are also returned from the stored procedure:
    /// 
    /// the values returned are:
    /// 
    /// static_AGEN_ID 
    /// static_COLLECTION_SYSTEM_ID
    /// static_LOADING_APPLICATION_ID
    /// static_METHOD_ID 
    /// static_COMPUTATION_ID 
    /// 
    /// To: DO... if application is not in HDB2 give good error message:
    /// 
    /// </summary>
    static void LookupApplication()
    {
      OleDbCommand cmd = new OleDbCommand("LOOKUP_APPLICATION");
      cmd.CommandType = CommandType.StoredProcedure;
      
      string agen_id_name = System.Configuration.ConfigurationSettings.AppSettings["AGEN_ID_NAME"];
      try
      {
        //inputs
        cmd.Parameters.Add("AGEN_ID_NAME",OleDbType.VarChar );
        cmd.Parameters["AGEN_ID_NAME"].Value =agen_id_name;
        cmd.Parameters["AGEN_ID_NAME"].Direction = ParameterDirection.Input ;

        cmd.Parameters.Add("COLLECTION_SYSTEM_NAME",OleDbType.VarChar);
        cmd.Parameters["COLLECTION_SYSTEM_NAME"].Value ="(see agency)";
        cmd.Parameters["COLLECTION_SYSTEM_NAME"].Direction = ParameterDirection.Input ;
      
        cmd.Parameters.Add("LOADING_APPLICATION_NAME",OleDbType.VarChar);
        cmd.Parameters["LOADING_APPLICATION_NAME"].Value ="HDB-POET";
        cmd.Parameters["LOADING_APPLICATION_NAME"].Direction = ParameterDirection.Input ;
      
        cmd.Parameters.Add("METHOD_NAME",OleDbType.VarChar);
        cmd.Parameters["METHOD_NAME"].Value ="unknown";
        cmd.Parameters["METHOD_NAME"].Direction = ParameterDirection.Input ;
      
        cmd.Parameters.Add("COMPUTATION_NAME",OleDbType.VarChar);
        cmd.Parameters["COMPUTATION_NAME"].Value ="unknown";
        cmd.Parameters["COMPUTATION_NAME"].Direction = ParameterDirection.Input ;
      
        //output
        /*
         * ' output
      param = New SqlParameter
      param.ParameterName = "@rval"
      param.DbType = DbType.AnsiStringFixedLength
      param.Direction = ParameterDirection.Output
      param.Size = 22

      cmd.Parameters.Add(param)

         * */
        cmd.Parameters.Add("AGEN_ID",OleDbType.Numeric);
        cmd.Parameters["AGEN_ID"].Direction = ParameterDirection.Output;

        cmd.Parameters.Add("COLLECTION_SYSTEM_ID",OleDbType.Numeric);
        cmd.Parameters["COLLECTION_SYSTEM_ID"].Direction = ParameterDirection.Output ;
      
        cmd.Parameters.Add("LOADING_APPLICATION_ID",OleDbType.Numeric);
        cmd.Parameters["LOADING_APPLICATION_ID"].Direction = ParameterDirection.Output;
      
        cmd.Parameters.Add("METHOD_ID",OleDbType.Numeric);
        cmd.Parameters["METHOD_ID"].Direction = ParameterDirection.Output ;
      
        cmd.Parameters.Add("COMPUTATION_ID",OleDbType.Numeric);
        cmd.Parameters["COMPUTATION_ID"].Direction = ParameterDirection.Output ;
      
        oracle.RunStoredProc(cmd);
        static_AGEN_ID = Convert.ToDecimal(cmd.Parameters["AGEN_ID"].Value);
        static_COLLECTION_SYSTEM_ID = Convert.ToDecimal(cmd.Parameters["COLLECTION_SYSTEM_ID"].Value);
        static_LOADING_APPLICATION_ID = Convert.ToDecimal(cmd.Parameters["LOADING_APPLICATION_ID"].Value);
        static_METHOD_ID = Convert.ToDecimal(cmd.Parameters["METHOD_ID"].Value);
        static_COMPUTATION_ID = Convert.ToDecimal(cmd.Parameters["COMPUTATION_ID"].Value);
    
      }
      catch(Exception e)
      {
        MessageBox.Show("Oracle Error: "+e.Message);
      }

    }

    

    /// <summary>
    /// Wrapper function to call the stored procedure named modify_r_base.
    /// This function is called for each time series value that is modified or 
    /// inserted.
    /// </summary>
    /// <param name="SITE_DATATYPE_ID"></param>
    /// <param name="INTERVAL"></param>
    /// <param name="START_DATE_TIME"></param>
    /// <param name="END_DATE_TIME"></param>
    /// <param name="VALUE"></param>
    /// <param name="OVERWRITE_FLAG"></param>
    /// <param name="VALIDATION"></param>
    /// <param name="DO_UPDATE_Y_OR_N"></param>
    /// <returns></returns>
    public static int modify_r_base(
      decimal  SITE_DATATYPE_ID,
      string   INTERVAL, // 'instant', 'other', 'hour', 'day', 'month', 'year', 'wy', 'table interval'
      DateTime START_DATE_TIME,
      DateTime END_DATE_TIME,
      double   VALUE,
      string   OVERWRITE_FLAG, //   'O'  'null' 
      string   VALIDATION, // 'V' '-' 'Z'
      string   DO_UPDATE_Y_OR_N ) //if inserting new value 'N' otherwise 'Y'
    {

      if (static_AGEN_ID==HDB_INVALID_ID)
      {
        HDB.LookupApplication();
      }

      return modify_r_base_raw( 
        SITE_DATATYPE_ID,
        INTERVAL,
        START_DATE_TIME,
        END_DATE_TIME,
        VALUE,
        static_AGEN_ID,
        OVERWRITE_FLAG,
        VALIDATION,
        static_COLLECTION_SYSTEM_ID,
        static_LOADING_APPLICATION_ID,
        static_METHOD_ID,
        static_COMPUTATION_ID,
        DO_UPDATE_Y_OR_N );

    }


    /// <summary>
    /// Wrapper for stored procedure MODIFY_R_BASE_RAW
    /// </summary>
    private static int modify_r_base_raw(
      decimal  SITE_DATATYPE_ID,
      string   INTERVAL, // 'instant', 'other', 'hour', 'day', 'month', 'year', 'wy', 'table interval'
      DateTime START_DATE_TIME,
      DateTime END_DATE_TIME,
      double   VALUE,
      decimal  AGEN_ID, // 7 'Bureau of Reclamation'
      string   OVERWRITE_FLAG, //   'O'  'null' 
      string   VALIDATION, // 'V' '-' 'Z'
      decimal  COLLECTION_SYSTEM_ID, // 5 'Manual Update'
      decimal  LOADING_APPLICATION_ID, // 8 = 'usgs2hdb.pl'
      // lookup name 'gnumono' to get number
      decimal  METHOD_ID, //15, method unknown
      decimal  COMPUTATION_ID, //1, unknown
      string   DO_UPDATE_Y_OR_N ) //if inserting new value 'N' otherwise 'Y'
    {
      OleDbCommand cmd = new OleDbCommand("MODIFY_R_BASE_RAW");
      cmd.CommandType = CommandType.StoredProcedure;
      
      cmd.Parameters.Add("SITE_DATATYPE_ID",OleDbType.Numeric);
      cmd.Parameters["SITE_DATATYPE_ID"].Value =SITE_DATATYPE_ID;
      cmd.Parameters["SITE_DATATYPE_ID"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("INTERVAL",OleDbType.VarChar);
      cmd.Parameters["INTERVAL"].Value =INTERVAL;
      cmd.Parameters["INTERVAL"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("START_DATE_TIME",OleDbType.Date);
      cmd.Parameters["START_DATE_TIME"].Value =START_DATE_TIME;
      cmd.Parameters["START_DATE_TIME"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("END_DATE_TIME",OleDbType.Date);
      if( END_DATE_TIME == DateTime.MinValue)
      {
        cmd.Parameters["END_DATE_TIME"].Value =DBNull.Value;
      }
      else
      {
        cmd.Parameters["END_DATE_TIME"].Value =END_DATE_TIME;
      }

      cmd.Parameters["END_DATE_TIME"].Direction = ParameterDirection.InputOutput ;
      
      cmd.Parameters.Add("VALUE",OleDbType.Double);
      cmd.Parameters["VALUE"].Value =VALUE;
      cmd.Parameters["VALUE"].Direction = ParameterDirection.Input ;

      cmd.Parameters.Add("AGEN_ID",OleDbType.Numeric);
      cmd.Parameters["AGEN_ID"].Value =AGEN_ID;
      cmd.Parameters["AGEN_ID"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("OVERWRITE_FLAG",OleDbType.VarChar);
      if(OVERWRITE_FLAG == null)
      {
        cmd.Parameters["OVERWRITE_FLAG"].Value =DBNull.Value;  //OVERWRITE_FLAG
      }
      else
      {
        cmd.Parameters["OVERWRITE_FLAG"].Value =OVERWRITE_FLAG;
      }
      cmd.Parameters["OVERWRITE_FLAG"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("VALIDATION",OleDbType.VarChar);
      cmd.Parameters["VALIDATION"].Value =VALIDATION;
      cmd.Parameters["VALIDATION"].Direction = ParameterDirection.Input ;
      
    

      cmd.Parameters.Add("COLLECTION_SYSTEM_ID",OleDbType.Numeric);
      cmd.Parameters["COLLECTION_SYSTEM_ID"].Value =COLLECTION_SYSTEM_ID;
      cmd.Parameters["COLLECTION_SYSTEM_ID"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("LOADING_APPLICATION_ID",OleDbType.Numeric);
      cmd.Parameters["LOADING_APPLICATION_ID"].Value =LOADING_APPLICATION_ID;
      cmd.Parameters["LOADING_APPLICATION_ID"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("METHOD_ID",OleDbType.Numeric);
      cmd.Parameters["METHOD_ID"].Value =METHOD_ID;
      cmd.Parameters["METHOD_ID"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("COMPUTATION_ID",OleDbType.Numeric);
      cmd.Parameters["COMPUTATION_ID"].Value =COMPUTATION_ID;
      cmd.Parameters["COMPUTATION_ID"].Direction = ParameterDirection.Input ;
      
      cmd.Parameters.Add("DO_UPDATE_Y_OR_N",OleDbType.VarChar);
      cmd.Parameters["DO_UPDATE_Y_OR_N"].Value =DO_UPDATE_Y_OR_N;
      cmd.Parameters["DO_UPDATE_Y_OR_N"].Direction = ParameterDirection.Input ;
      
      int rval =0;
      try
      {
        rval = oracle.RunStoredProc(cmd);
      }
      catch(Exception e)
      {
        MessageBox.Show("Oracle Error: "+e.Message);
      }
      return rval;
    }
      
      public static void check_valid_role_name(string role)
      {
        try
        {
          OleDbCommand cmd = new OleDbCommand("PSSWD_USER.check_valid_role_name");
          cmd.CommandType = CommandType.StoredProcedure;
          cmd.Parameters.Add("amount",OleDbType.VarChar);
          cmd.Parameters["amount"].Value = role;
          cmd.Parameters["amount"].Direction = ParameterDirection.Input ;
          oracle.RunStoredProc(cmd);
        }
        catch(Exception e)
        {
      MessageBox.Show("Oracle Error: "+e.Message);
        }
      }
      
      
    public static DataTable Table(decimal site_datatype_id, string r_table,
      DateTime time1, DateTime time2)
    {
      string date_column = "start_date_time";
      //string sql = "select "+date_column+", value, method_id, overwrite_flag from " + r_table 
		string sql = "select "+date_column+", value from " + r_table 
        +" where site_datatype_id ="+site_datatype_id
        +" and "+date_column+ " >= "+OracleDate(time1)
        +" and "+date_column+ " <= "+OracleDate(time2);
      Console.WriteLine(sql);
      DataTable rval = oracle.Table(r_table,sql);
      if( rval == null)
      {
       rval = new DataTable();
        rval.Columns.Add(new DataColumn(date_column,typeof(DateTime)));
        rval.Columns.Add(new DataColumn("value",typeof(double)));

      }
      Console.WriteLine("read "+ rval.Rows.Count+" rows ");
      return rval;
    }

	public static void Fill(TimeSeriesDataSet graphDef)
    {
      int sz = graphDef.Series.Count;
      for(int i=0; i<sz; i++)
        {
        string tableName = "table"+i;
        if( graphDef.Tables.Contains(tableName))
          graphDef.Tables.Remove(tableName);
        }
       
		if( graphDef.Graph.Count ==0)
		{
			graphDef.Graph.AddGraphRow("untitled","TimeSeries",DateTime.Now.AddDays(-356),DateTime.Now,DateTime.Now.AddDays(-356),2,false,"");
		}
         // create a default time and title for graphs.

		DataTable uniqueSites = Karl.Tools.SimplePivotTable.Unique("unique",graphDef.Series,"SiteName");
		DataTable uniqueDataTypes = Karl.Tools.SimplePivotTable.Unique("uniqueDataType",graphDef.Series,"ParameterType");

       graphDef.Graph[0].Title= "";
	   
		bool HasMultipleSites = (uniqueSites.Rows.Count>1);
		bool HasMultipleDataTypes =  (uniqueDataTypes.Rows.Count>1);
		  // If there is just one site .. use the site name in the title.
		if(!HasMultipleSites)
		{
			graphDef.Graph[0].Title= graphDef.Series[0].SiteName;
		}
          
		// if all data types are the same append it to the title.
		if(!HasMultipleDataTypes)
		{
			graphDef.Graph[0].Title +=" "+ graphDef.Series[0].ParameterType;
		}
		  

       
      for(int i=0; i<sz; i++)
      {
        graphDef.Series[i].Title= graphDef.Series[i].ParameterType;
		  // If there are multiple sites, append site name to legend.
		  if(HasMultipleSites)
		  {
			graphDef.Series[i].Title =  graphDef.Series[i].SiteName
				                       +" "+graphDef.Series[i].ParameterType; 
		  }
        DataTable tbl = Table(graphDef.Series[i].hdb_site_datatype_id,
          graphDef.Series[i].hdb_r_table, /* table name  i.e.  'r_month' */
          TimeSeriesTools.BeginingTime(graphDef),
          TimeSeriesTools.EndingTime(graphDef));
			
        tbl.TableName="table"+i;
        graphDef.Series[i].TableName = tbl.TableName;
        tbl.DataSet.Tables.Remove(tbl);
        graphDef.Tables.Add(tbl);
      }

    }
    /// <summary>
    /// Returns table of hdb data categoritgs.
    /// i.e.  Stream, Reservoir, Climate, etc...
    /// </summary>
    /// <returns></returns>
    public static DataTable Categories
    {
    get{
      if( _categories == null)
       {
       string sql = "select * from hdb_objecttype";
       _categories = oracle.Table("Categories",sql);
       }
      return _categories;
      }
    }
    	
		public static DataTable HDB_objecttype
		{
		  get {
		      if(_object_types == null)
		        {
		        _object_types = oracle.Table("hdb_objecttype","select * from hdb_objecttype");
		        }
		      return _object_types;
		      }
		}
		
		public static DataSet BuildSiteList()
		{	
			string filename = "SiteList.xml";
			string[] tables=
			{
				"hdb_site_datatype",
				"hdb_site",
				"hdb_datatype",
				"hdb_unit",
				"ref_hm_site_pcode",
				"ref_hm_site",
				"ref_hm_filetype",
				"hdb_objecttype"
			};

			DataSet ds =new DataSet("SiteList");
			if(File.Exists(filename))
			{
				ds.ReadXml(filename,XmlReadMode.ReadSchema);
			}
			for(int i=0; i<tables.Length; i++)
			{
				if( ds.Tables.Contains(tables[i]))
					continue;

				DataTable t = oracle.Table(tables[i],"select * from "+tables[i]);
				t.DataSet.Tables.Remove(t);
				ds.Tables.Add(t);
			}
			//ds.WriteXml(filename,XmlWriteMode.WriteSchema);
      return ds;
		
		}

	
			 

/// <summary>
/// Gets list of sites for the graph series editor (graph properties)
/// </summary>
   public static DataTable FilteredSiteList(string siteSearchString, 
                                          string[] r_names, 
                                          int[] categories,
                                          DateTime dateBegin,
                                          DateTime dateEnd)
   {
     string sql_template  =	"select c.site_id, c.site_common_name, lower(c.site_common_name),c.objecttype_id from #TABLE_NAME# a, "
       +"hdb_site_datatype b, hdb_site c " 
       +"where a.site_datatype_id = b.site_datatype_id and "
       +"b.site_id = c.site_id and a.start_date_time between "
       +OracleDate(dateBegin)+" and "+OracleDate(dateEnd)+" ";
       
       if( siteSearchString.Trim() != "")
        {
          sql_template += " and lower(c.site_common_name) like '%"+siteSearchString.ToLower().Trim()+"%'";
        }
        if( categories.Length >0)
        {
         sql_template += " and (";
          for(int i=0; i<categories.Length; i++)
            {
            sql_template += " c.objecttype_id = "+categories[i];
            if( i<categories.Length-1)
             {
              sql_template += " or ";
             }
            }
           sql_template += " ) ";
        }
       

    if( r_names.Length ==1)
       {
       sql_template = sql_template.Replace("select ","select distinct ");
       }
       string sql="";
       for( int i =0; i<r_names.Length; i++)
         {
        int idx = Array.IndexOf(HDB.r_names,r_names[i]);
          Debug.Assert(idx >=0);
         string tableName = HDB.r_tables[idx];
         sql += sql_template;
         sql = sql.Replace("#TABLE_NAME#",tableName);
         
         if( i < r_names.Length-1)
           {// append union keyword
            sql += " UNION \n";
           }
         }
       sql += " order by site_common_name";
       DataTable rval = oracle.Table("SiteList",sql);
       
//       DataTable t =  HDB.HDB_objecttype;
       
       
       
       return rval;
   }
   
#region // sql to get info for a specific site, including period of record.   
   /*
   select 'INSTANT' interval,d.datatype_id, d.datatype_common_name,
count(a.value), min(start_date_time), max(start_date_time)
from
r_instant a, hdb_site_datatype b, hdb_datatype d
where
a.site_datatype_id = b.site_datatype_id and
b.datatype_id = d.datatype_id and
b.site_id = 919
group by d.datatype_id, d.datatype_common_name
UNION
select 'Hour' interval,d.datatype_id, d.datatype_common_name,
count(a.value), min(start_date_time), max(start_date_time)
from
r_hour a, hdb_site_datatype b, hdb_datatype d
where
a.site_datatype_id = b.site_datatype_id and
b.datatype_id = d.datatype_id and
b.site_id = 919
group by d.datatype_id, d.datatype_common_name
UNION

select 'DAY' interval,d.datatype_id, d.datatype_common_name,
count(a.value), min(start_date_time), max(start_date_time)
from
r_day a, hdb_site_datatype b, hdb_datatype d
where
a.site_datatype_id = b.site_datatype_id and
b.datatype_id = d.datatype_id and
b.site_id = 919
group by d.datatype_id, d.datatype_common_name
UNION
select 'MONTH' interval, d.datatype_id, d.datatype_common_name,
count(a.value), min(start_date_time), max(start_date_time)
from
r_month a, hdb_site_datatype b, hdb_datatype d
where
a.site_datatype_id = b.site_datatype_id and
b.datatype_id = d.datatype_id and
b.site_id = 919 
group by d.datatype_id, d.datatype_common_name
UNION
select 'YEAR' interval,d.datatype_id, d.datatype_common_name,
count(a.value), min(start_date_time), max(start_date_time)
from
r_year a, hdb_site_datatype b, hdb_datatype d
where
a.site_datatype_id = b.site_datatype_id and
b.datatype_id = d.datatype_id and
b.site_id = 919
group by d.datatype_id, d.datatype_common_name
UNION
select 'WATER YEAR' interval,d.datatype_id, d.datatype_common_name,
count(a.value), min(start_date_time), max(start_date_time)
from
r_wy a, hdb_site_datatype b, hdb_datatype d
where
a.site_datatype_id = b.site_datatype_id and
b.datatype_id = d.datatype_id and
b.site_id = 919
group by d.datatype_id, d.datatype_common_name
;*/
#endregion
/// <summary>
/// SiteInfo returns a list of data types and the period of record for
/// each data type.  For example the following table is returned for site 919
/// Connected.
///
 ///   INTERVA DATATYPE_ID DATATYPE_COMMON_NAME                                             COUNT(A.VALUE) rtable  site_datatype_id    site_id MIN(START MAX(START
///   ------- ----------- ---------------------------------------------------------------- -------------- ------- ---------------- ---------- --------- ---------
///    daily            17 reservoir storage, end of period reading used as value for per.            5046 r_day               1730        932 01-OCT-70 08-JUL-03
///    daily            29 average inflow                                                             4553 r_day               1801        932 02-OCT-90 08-JUL-03
///    daily            42 average sum of all reservoir releases (pwr and oth)                        4552 r_day               1881        932 02-OCT-90 08-JUL-03
///    daily            49 reservoir WS elevation, end of per reading used as value for per           5044 r_day               1937        932 01-OCT-70 08-JUL-03
///    monthly          17 reservoir storage, end of period reading used as value for per.             389 r_month             1730        932 01-OCT-70 01-FEB-03
///    monthly          49 reservoir WS elevation, end of per reading used as value for per            120 r_month             1937        932 01-OCT-70 01-JUL-86
/// </summary>
 public static DataTable SiteInfo(int site_datatype_id, string[] r_names)
  {
  
  string sql_template  = 
               "  select '#RNAMES#' interval,d.datatype_id, d.datatype_common_name, "
            +  " count(a.value),'#TABLE_NAME#' \"rtable\", max(a.site_datatype_id) "
            +  " \"site_datatype_id\" ,max(b.site_id) \"site_id\", min(start_date_time), "
            +  " max(start_date_time), max(e.unit_common_name) \"unit_common_name\", max(c.site_common_name) \"site_common_name\"  "
            +  " from "
            +  " #TABLE_NAME# a, hdb_site_datatype b, hdb_site c, hdb_datatype d, hdb_unit e "
            +  " where "
            +  " a.site_datatype_id = b.site_datatype_id and "
            +  " b.datatype_id = d.datatype_id and c.site_id ="+site_datatype_id.ToString()
            +  "  and e.unit_id = d.unit_id and "
            +  " b.site_id = "+site_datatype_id.ToString()
            +  " group by d.datatype_id, d.datatype_common_name ";
   string sql="";
   for( int i =0; i<r_names.Length; i++)
   {
     int idx = Array.IndexOf(HDB.r_names,r_names[i]);
     Debug.Assert(idx >=0);
     string tableName = HDB.r_tables[idx];
     sql += sql_template;
     sql = sql.Replace("#TABLE_NAME#",tableName);
     sql = sql.Replace("#RNAMES#",HDB.r_names[idx]);
         
     if( i < r_names.Length-1)
     {// append union keyword
       sql += " UNION \n";
     }
   }
       
   DataTable rval = oracle.Table("SiteInfo",sql);
            
  return rval;
  
  }
	}
}
