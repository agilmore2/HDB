using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;
using System.IO;
using Karl.Tools;
using Karl.Tools.TimeSeries;
namespace HDBBrowser
{
	public class GraphProperties : System.Windows.Forms.Form
	{
		TimeSeriesDataSet graphDef;
		DataTable siteTableFiltered;

		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBoxKeyWords;
		private System.Windows.Forms.Button buttonRefresh;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListBox listBoxCategory;
		private MWControls.MWTreeView treeView1;
		private System.Windows.Forms.Button buttonOk;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListBox listBoxInterval;
		private System.Windows.Forms.StatusBar statusBar1;
		private Karl.Tools.TimeSeries.DateSelector dateSelector1;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public GraphProperties(TimeSeriesDataSet dataSet)
		{
			InitializeComponent();
			SetupListBoxes();
			DataSet=dataSet;
		}
    
		public TimeSeriesDataSet  DataSet 
		{
			set { 
				
				 this.graphDef = value;
				this.dateSelector1.ReadFromDataSet(this.graphDef);
				if( treeView1.Nodes.Count>0)
				  treeView1.Nodes[0].Expand();
			     }
			get { return this.graphDef;}
    	}
    
    
    /// <summary>
    /// Fill in list boxes that show different ways to filter the selection tree.
    /// </summary>
		void SetupListBoxes()
		{
			//categories
			DataTable t =  HDB.HDB_objecttype;
			DataRow r = t.NewRow();
			this.listBoxCategory.Items.Clear();
			for(int i=0; i<t.Rows.Count; i++)
			{
				this.listBoxCategory.Items.Add(t.Rows[i]["objecttype_name"]);
			}
			this.listBoxCategory.SelectedIndex =0;

			this.listBoxInterval.Items.Clear();
			string[] intervalNames = HDB.r_names;
			for(int i=0; i<intervalNames.Length; i++)
			{
				this.listBoxInterval.Items.Add(intervalNames[i]);
			}
			this.listBoxInterval.SelectedIndex =0;
		}

    /// <summary>
    /// using the filtered site list build a tree that
    /// has datatype (such as 'flow')as the sub-branches.
    /// The Tag property of each tree node continas the important HDB site_datatype_id
    /// </summary>
		void LoadTree()
		{
			this.treeView1.Nodes.Clear();
			TreeNode node;
			string rootName = HDB.Oracle.ServiceName+" Sites";
			TreeNode root = new TreeNode(rootName);
			treeView1.Nodes.Add(root);
			int sz = this.siteTableFiltered.Rows.Count;
			for(int i=0; i<sz; i++) // Each Site
			{
				node = new TreeNode((string)siteTableFiltered.Rows[i]["SITE_Common_NAME"]);
				node.Tag = this.siteTableFiltered.Rows[i];
				node.Nodes.Add("expand_this_site");
				root.Nodes.Add(node);
			}
			root.Expand();
		}

		/*
    void LoadInitialTree()
    {
        this.treeView1.Nodes.Clear();
        TreeNode node;
        string rootName = HDB.Oracle.ServiceName+" Sites";
        TreeNode root = new TreeNode(rootName);
        treeView1.Nodes.Add(root);
        int sz = this.graphDef.Series.Count;
        for(int i=0; i<sz; i++) // Each Site
        {
          node = new TreeNode(graphDef.Series[i].SiteName+" : "+graphDef.Series[i].ParameterType);
          node.Tag = null;
          root.Nodes.Add(node);
        }
        root.Expand();

    }
*/
		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label2 = new System.Windows.Forms.Label();
			this.textBoxKeyWords = new System.Windows.Forms.TextBox();
			this.buttonRefresh = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.listBoxCategory = new System.Windows.Forms.ListBox();
			this.treeView1 = new MWControls.MWTreeView();
			this.buttonOk = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.dateSelector1 = new Karl.Tools.TimeSeries.DateSelector();
			this.listBoxInterval = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(160, 16);
			this.label2.TabIndex = 11;
			this.label2.Text = "site name search string";
			// 
			// textBoxKeyWords
			// 
			this.textBoxKeyWords.Location = new System.Drawing.Point(8, 32);
			this.textBoxKeyWords.Name = "textBoxKeyWords";
			this.textBoxKeyWords.Size = new System.Drawing.Size(216, 20);
			this.textBoxKeyWords.TabIndex = 10;
			this.textBoxKeyWords.Text = "";
			// 
			// buttonRefresh
			// 
			this.buttonRefresh.Location = new System.Drawing.Point(256, 152);
			this.buttonRefresh.Name = "buttonRefresh";
			this.buttonRefresh.Size = new System.Drawing.Size(112, 23);
			this.buttonRefresh.TabIndex = 9;
			this.buttonRefresh.Text = "create list of sites";
			this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 72);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 16);
			this.label3.TabIndex = 7;
			this.label3.Text = "site type";
			// 
			// listBoxCategory
			// 
			this.listBoxCategory.Location = new System.Drawing.Point(8, 96);
			this.listBoxCategory.Name = "listBoxCategory";
			this.listBoxCategory.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.listBoxCategory.Size = new System.Drawing.Size(216, 82);
			this.listBoxCategory.TabIndex = 17;
			// 
			// treeView1
			// 
			this.treeView1.ImageIndex = -1;
			this.treeView1.Location = new System.Drawing.Point(8, 208);
			this.treeView1.MultiSelect = MWCommon.TreeViewMultiSelect.MultiSameLevel;
			this.treeView1.Name = "treeView1";
			this.treeView1.SelectedImageIndex = -1;
			this.treeView1.Size = new System.Drawing.Size(688, 352);
			this.treeView1.TabIndex = 20;
			this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
			this.treeView1.AfterExpand += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
			this.treeView1.AfterSelNodeChanged += new System.EventHandler(this.treeView1_AfterSelNodeChanged);
			// 
			// buttonOk
			// 
			this.buttonOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonOk.Location = new System.Drawing.Point(728, 512);
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.TabIndex = 29;
			this.buttonOk.Text = "Ok";
			this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.dateSelector1);
			this.groupBox1.Controls.Add(this.listBoxInterval);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.textBoxKeyWords);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.listBoxCategory);
			this.groupBox1.Controls.Add(this.buttonRefresh);
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(792, 200);
			this.groupBox1.TabIndex = 30;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Site List Criteria";
			// 
			// dateSelector1
			// 
			this.dateSelector1.Location = new System.Drawing.Point(424, 8);
			this.dateSelector1.Name = "dateSelector1";
			this.dateSelector1.ShowTime = false;
			this.dateSelector1.Size = new System.Drawing.Size(360, 184);
			this.dateSelector1.TabIndex = 22;
			this.dateSelector1.Validating += new System.ComponentModel.CancelEventHandler(this.dateSelector1_Validating);
			// 
			// listBoxInterval
			// 
			this.listBoxInterval.Location = new System.Drawing.Point(248, 24);
			this.listBoxInterval.Name = "listBoxInterval";
			this.listBoxInterval.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
			this.listBoxInterval.Size = new System.Drawing.Size(168, 82);
			this.listBoxInterval.TabIndex = 21;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(248, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(104, 16);
			this.label1.TabIndex = 20;
			this.label1.Text = "time series interval";
			// 
			// buttonCancel
			// 
			this.buttonCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.buttonCancel.CausesValidation = false;
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Location = new System.Drawing.Point(728, 552);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.TabIndex = 32;
			this.buttonCancel.Text = "Cancel";
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 582);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(808, 16);
			this.statusBar1.TabIndex = 33;
			// 
			// GraphProperties
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(808, 598);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.buttonOk);
			this.Controls.Add(this.treeView1);
			this.Name = "GraphProperties";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Edit Graph Series";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void buttonRefresh_Click(object sender, System.EventArgs e)
		{
		Cursor = Cursors.WaitCursor;
			try
			{
			string[] intervalDescriptions = new string[listBoxInterval.SelectedItems.Count];
			listBoxInterval.SelectedItems.CopyTo(intervalDescriptions,0);
			
			int[] categories = new int[listBoxCategory.SelectedIndices.Count];
			listBoxCategory.SelectedIndices.CopyTo(categories,0);
			DataTable tbl = HDB.HDB_objecttype;
			for(int i=0; i<categories.Length; i++)
			  { // switch from indices to objecttype_id
			   categories[i] = (int)(decimal) tbl.Rows[categories[i]]["objecttype_id"];
			  
			  }
      this.dateSelector1.SaveToDataSet(this.graphDef);
			siteTableFiltered = HDB.FilteredSiteList(this.textBoxKeyWords.Text,
			                   intervalDescriptions ,
			                   categories,
			                   TimeSeriesTools.BeginingTime(this.graphDef),
			                   TimeSeriesTools.EndingTime(this.graphDef));
			LoadTree();
			}
			finally{
			Cursor = Cursors.Default;
			}
		}

    void SaveTree()
    {
    //this.treeView1.S
    }
		private void treeView1_AfterSelect(object sender, System.Windows.Forms.TreeViewEventArgs e)
		{
			try
			{
				Cursor = Cursors.WaitCursor;
        string[] intervalDescriptions = new string[listBoxInterval.SelectedItems.Count];
        listBoxInterval.SelectedItems.CopyTo(intervalDescriptions,0);
			
				TreeNode root = e.Node;
				if(    root.Nodes.Count ==1 && root.Tag != null
					&& root.Nodes[0].Text == "expand_this_site")
				{
					// nodes parent hasn't been selected yet..
					//fill in data.
					DataRow row = (DataRow) root.Tag;
					int site_id = (int)(decimal)row["site_id"];
					DataTable tblSiteInfo = HDB.SiteInfo(site_id,intervalDescriptions);
					
					DataTable tblUnique = Karl.Tools.SimplePivotTable.Unique("intervals",tblSiteInfo,"INTERVAL");
					bool multipleDataTypes = (tblUnique.Rows.Count >1);
					root.Nodes.Clear();
					
					if( multipleDataTypes)
					  {// add tree structure to organize data into daily,hourly, monthly,etc...
					  foreach (DataRow r in tblUnique.Rows)
					       {
					        TreeNode n = new TreeNode(r[0].ToString());
					        //n.Tag = r;
					        root.Nodes.Add(n);
					       }
					  }
					
					for(int interval = 0; interval<tblUnique.Rows.Count; interval++)
					{
					 DataTable tbl;
					 if( multipleDataTypes)
					   {
					   tbl = Karl.Tools.SimplePivotTable.Filter(tblSiteInfo,"interval = '"+tblUnique.Rows[interval][0].ToString()+"'");
					   }
					 else
					   {
					    tbl = tblSiteInfo;
					   }
					  for(int i=0; i<tbl.Rows.Count; i++)
					  {
					  string text = "";
					    if( !multipleDataTypes)
					      {
					      text = tblUnique.Rows[0][0]+" : ";
					      }
						  text += (string)tbl.Rows[i]["DATATYPE_COMMON_NAME"];
						  text +=  " "+tbl.Rows[i]["COUNT(A.VALUE)"];
						  text += " records";
						  text += " "+((DateTime)tbl.Rows[i]["min(start_date_time)"]).ToString("MMM-dd-yyyy")
						       +  " --> "
						       +   ((DateTime)tbl.Rows[i]["max(start_date_time)"]).ToString("MMM-dd-yyyy");;
						  TreeNode node = new TreeNode(text);
						  node.Tag = tbl.Rows[i];
						  if(multipleDataTypes)
						   {
						    root.Nodes[interval].Nodes.Add(node);
						   }
						   else
						   {
						  root.Nodes.Add(node);
						  }
					  }
					}
					//root.ExpandAll();
				}
				if(e.Node.Text!= "HDB Sites") 
				{
				UpdateSelectedSeries(); 
				}
			}
			finally
			{
			Cursor = Cursors.Default;
			}
		}

		/// <summary>
		/// Creates a list of series that will be used for a graph.
		/// </summary>
		void UpdateSelectedSeries()
		{
		 graphDef.Series.Rows.Clear();		 


    try
    {
		int count = treeView1.SelNodes.Count;

		ICollection ic =treeView1.SelNodes.Values;
		IEnumerator ie = ic.GetEnumerator();
		ie.Reset();
		bool ok = ie.MoveNext();
         
			while( ok)
			{
			MWCommon.MWTreeNodeWrapper mwtnw = (MWCommon.MWTreeNodeWrapper)ie.Current;
			TreeNode node = mwtnw.Node;
				if( node.Nodes.Count==0 && node.Parent!= null && node.Parent.Parent!=null ) 
				{
				  DataRow r_tableRow = (DataRow) node.Tag;
					TimeSeriesDataSet.SeriesRow row = graphDef.Series.NewSeriesRow();

					row.SiteName = (string)r_tableRow["site_common_name"];
					//row.ParameterType = node.Parent.Text;
					row.TimeStep = (string)r_tableRow["interval"];
					row.Source = "HDB";
					row.TagInfo= "";
					row.Units = (string)r_tableRow["unit_common_name"];
					//row.Title = (string)r_tableRow["datatype_common_name"];
					row.ParameterType=(string)r_tableRow["datatype_common_name"];
					row.hdb_site_datatype_id =(decimal)r_tableRow["site_datatype_id"];
					row.hdb_r_table = (string) r_tableRow["rtable"];
					graphDef.Series.AddSeriesRow(row);
				}

			ok = ie.MoveNext();
			}
			}
			catch(Exception exception)
			{
			  MessageBox.Show(exception.ToString());
			}
			
		  this.statusBar1.Text = graphDef.Series.Rows.Count+" selected";
		}

		private void treeView1_AfterSelNodeChanged(object sender, System.EventArgs e)
		{
		UpdateSelectedSeries();
		}

		private void buttonOk_Click(object sender, System.EventArgs e)
		{
      this.dateSelector1.SaveToDataSet(graphDef);
		 Close();
		}

    private void dateSelector1_Validating(object sender, System.ComponentModel.CancelEventArgs e)
    {
      if( TimeSeriesTools.BeginingTime(graphDef) >
        TimeSeriesTools.EndingTime(graphDef) )
      {
      //e.Cancel=true;
        //MessageBox.Show("Error: Ending date must be larger than start date");
      }
    }

    

		
	}
}
