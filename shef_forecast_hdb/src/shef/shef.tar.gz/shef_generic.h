#define DIRECTORY_OF_CFG "shef_generic.cfg"
char   *pname = "shef_decode";


